
CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY IDENTITY (1,1),
    FirstName VARCHAR(50) NOT NULL,
	MiddleName VARCHAR(50),
    LastName VARCHAR(50)NOT NULL,
    Email VARCHAR(100) UNIQUE,
    Phone VARCHAR(20) UNIQUE
);

CREATE TABLE Orders (
    OrderID INT PRIMARY KEY IDENTITY (1,1),
    CustomerID INT NOT NULL,
    OrderDate DATE,
    TotalAmount DECIMAL(10, 2),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

CREATE TABLE Order_food (
	Order_food_ID INT PRIMARY KEY IDENTITY (1,1),
	Name_of_food VARCHAR (50) NOT NULL,
	FOREIGN KEY(Order_food_ID) REFERENCES Orders(OrderID),
);

INSERT INTO Customers (FirstName, MiddleName, LastName, Email, Phone)
VALUES ('John', 'Michael', 'Doe', 'john.doe@email.com', '123-456-7890'),
('Jane', 'Marie', 'Smith', 'jane.smith@email.com', '987-654-3210');

INSERT INTO Orders (CustomerID, OrderDate, TotalAmount)
VALUES (1, '2022-01-01', 100.00),
(2, '2022-01-02', 150.50);

INSERT INTO Order_food (Name_of_food)
VALUES ('Kasha');
